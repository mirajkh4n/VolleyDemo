package com.example.volleydemo;

public class MainData {
    // initialize variable
    private String name,image;

    // generate getter and setter

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
